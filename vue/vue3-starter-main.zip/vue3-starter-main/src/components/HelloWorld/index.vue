<template src="./HelloWorld.html"></template>
<style src="./HelloWorld.css"></style>
<script src="./HelloWorld.ts" lang="ts"></script>
