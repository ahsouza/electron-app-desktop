import { Options, Vue } from 'vue-class-component';

@Options({
    name: 'NavbarComponent',
})
export default class Navbar extends Vue {}
