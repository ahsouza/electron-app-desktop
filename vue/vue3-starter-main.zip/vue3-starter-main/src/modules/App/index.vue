<template src="./App.html"></template>
<style src="./App.css"></style>
<script src="./App.ts" lang="ts"></script>
